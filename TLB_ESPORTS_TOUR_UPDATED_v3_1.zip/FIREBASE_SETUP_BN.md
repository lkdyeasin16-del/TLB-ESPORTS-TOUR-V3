# TLB ESPORTS TOUR — Firebase setup

`google-services.json` is already placed in `app/google-services.json` for the Firebase Android app package `com.tlb.tournament`.

## Firebase console
1. Authentication → Sign-in method → Email/Password → Enabled.
2. Firestore Database → the database can remain in production mode.
3. Firestore → Rules → paste `firestore.rules` from this project and publish it.

## Make yourself admin
1. Install/run the app once and create a normal account.
2. Firebase Console → Firestore → `users` → open your UID document.
3. Change `role` from `user` to `admin`.
4. Log out/in again. The `ADMIN PANEL` button will appear.

## Admin panel
- Create Match
- Add TK to a user's wallet
- Approve/reject pending withdrawal requests

## User flow
- Sign up with username + email + exactly 6 digits.
- Login with username + 6-digit password.
- View realtime Match Found list.
- Join a match only once; entry fee is deducted atomically from wallet.
- Request withdrawal from 100–200 TK.

## Payment
This project does not fake real-money payment APIs. Real bKash/Nagad/Rocket payout needs merchant credentials, server-side verification, and the provider's current API flow.

## APK
Open this project in Android Studio and build the APK. This chat environment does not have a working Android SDK/Gradle build chain, so an installable APK cannot be truthfully claimed as already compiled here.
