package com.tlb.tournament;

import android.app.*;
import android.os.*;
import android.content.*;
import android.graphics.Color;
import android.graphics.drawable.GradientDrawable;
import android.text.InputType;
import android.view.*;
import android.widget.*;
import com.google.firebase.auth.*;
import com.google.firebase.firestore.*;
import java.util.*;
import java.util.regex.Pattern;

public class MainActivity extends Activity {
    FirebaseAuth auth;
    FirebaseFirestore db;
    LinearLayout box;
    final int BG=0xff080b10, CARD=0xff121722, WHITE=Color.WHITE, MUTED=0xffaeb8c5, ACCENT=0xffff1744;
    final String BKASH="01946220639", NAGAD="01934140030";

    @Override public void onCreate(Bundle b){
        super.onCreate(b); auth=FirebaseAuth.getInstance(); db=FirebaseFirestore.getInstance();
        if(auth.getCurrentUser()==null) showLogin(); else routeAfterLogin();
    }
    void routeAfterLogin(){
        if(BuildConfig.ADMIN_APP){ startActivity(new Intent(this,AdminActivity.class)); finish(); }
        else showHome();
    }
    ImageView logo(){ ImageView i=new ImageView(this); i.setImageResource(R.drawable.tlb_logo); i.setAdjustViewBounds(true); i.setScaleType(ImageView.ScaleType.CENTER_INSIDE); i.setPadding(12,8,12,8); return i; }
    TextView tv(String s,int size){ TextView t=new TextView(this); t.setText(s); t.setTextSize(size); t.setTextColor(WHITE); t.setPadding(0,8,0,8); return t; }
    TextView darkTv(String s,int size){ TextView t=tv(s,size); t.setTextColor(0xff222222); return t; }
    void base(){ box=new LinearLayout(this); box.setOrientation(LinearLayout.VERTICAL); box.setPadding(22,18,22,20); box.setBackgroundColor(BG); ScrollView sc=new ScrollView(this); sc.addView(box); setContentView(sc); }
    GradientDrawable bg(int color,int radius,int stroke){ GradientDrawable g=new GradientDrawable(); g.setColor(color); g.setCornerRadius(radius); if(stroke>0) g.setStroke(2,0xff33404f); return g; }
    EditText ed(String hint, boolean password){ EditText e=new EditText(this); e.setHint(hint); e.setTextSize(16); e.setSingleLine(true); e.setTextColor(WHITE); e.setHintTextColor(MUTED); e.setPadding(18,5,18,5); e.setBackground(bg(CARD,22,1)); if(password)e.setInputType(InputType.TYPE_CLASS_NUMBER|InputType.TYPE_NUMBER_VARIATION_PASSWORD); return e; }
    Button bt(String s){ Button b=new Button(this); b.setText(s); b.setTextSize(16); b.setTextColor(WHITE); b.setAllCaps(false); b.setBackground(bg(0xff151a24,22,1)); return b; }
    Button wide(String s){ Button b=bt(s); box.addView(b,new LinearLayout.LayoutParams(-1,58)); return b; }
    void space(int h){ TextView x=new TextView(this); box.addView(x,new LinearLayout.LayoutParams(1,h)); }
    String safe(String s,String d){ return s==null||s.trim().isEmpty()?d:s; }
    long val(DocumentSnapshot d,String k,long def){ Long x=d.getLong(k); return x==null?def:x; }
    void toast(String s){ Toast.makeText(this,s,Toast.LENGTH_LONG).show(); }

    void showLogin(){
        base(); box.addView(logo(),new LinearLayout.LayoutParams(-1,190));
        TextView h=tv(BuildConfig.ADMIN_APP?"TLB ADMIN":"TLB ESPORTS TOUR",29); h.setGravity(Gravity.CENTER); box.addView(h);
        TextView sub=tv(BuildConfig.ADMIN_APP?"ADMIN LOGIN":"LOGIN",21); sub.setGravity(Gravity.CENTER); box.addView(sub);
        EditText u=ed("Username or Email",false), p=ed("6-digit Password",true); box.addView(u,new LinearLayout.LayoutParams(-1,62)); space(8); box.addView(p,new LinearLayout.LayoutParams(-1,62)); space(12);
        Button login=bt(BuildConfig.ADMIN_APP?"Admin Login":"Login"); box.addView(login,new LinearLayout.LayoutParams(-1,60));
        if(!BuildConfig.ADMIN_APP){ TextView signup=tv("New user?  Sign Up",17); signup.setGravity(Gravity.CENTER); box.addView(signup); signup.setOnClickListener(v->showSignup()); }
        login.setOnClickListener(v->{ String user=u.getText().toString().trim(), pass=p.getText().toString(); if(user.isEmpty()){u.setError("Required");return;} if(!pass.matches("\\d{6}")){p.setError("Password must be exactly 6 digits");return;}
            String email=user; if(!user.contains("@")){ if(user.equalsIgnoreCase("admin")) email="tlbesportsorganisation@gmail.com"; else { db.collection("usernames").document(user.toLowerCase(Locale.US)).get().addOnSuccessListener(q->{ if(!q.exists()){u.setError("Username not found");return;} signIn(q.getString("email"),pass); }).addOnFailureListener(e->toast("Could not contact Firebase")); return; } }
            signIn(email,pass);
        });
    }
    void signIn(String email,String pass){ auth.signInWithEmailAndPassword(email,pass).addOnSuccessListener(x->{ if(BuildConfig.ADMIN_APP){ db.collection("users").document(auth.getUid()).get().addOnSuccessListener(d->{ if("admin".equals(d.getString("role"))) routeAfterLogin(); else {auth.signOut();toast("Admin access denied");} }); } else routeAfterLogin(); }).addOnFailureListener(e->toast("Login failed: "+safe(e.getMessage(),"check login details"))); }

    void showSignup(){
        base(); box.addView(logo(),new LinearLayout.LayoutParams(-1,180)); TextView h=tv("CREATE ACCOUNT",28);h.setGravity(Gravity.CENTER);box.addView(h);
        EditText u=ed("Username",false), e=ed("Email",false), p=ed("Exactly 6 digits",true), cp=ed("Confirm password",true); e.setInputType(33);
        box.addView(u,new LinearLayout.LayoutParams(-1,62));space(7);box.addView(e,new LinearLayout.LayoutParams(-1,62));space(7);box.addView(p,new LinearLayout.LayoutParams(-1,62));space(7);box.addView(cp,new LinearLayout.LayoutParams(-1,62));space(12);
        Button b=bt("Sign Up");box.addView(b,new LinearLayout.LayoutParams(-1,60));TextView back=tv("Already have an account? Login",17);back.setGravity(Gravity.CENTER);box.addView(back);
        b.setOnClickListener(v->{ String user=u.getText().toString().trim(), email=e.getText().toString().trim(), pass=p.getText().toString(), c=cp.getText().toString();
            if(!Pattern.matches("^[A-Za-z0-9_]{3,20}$",user)){u.setError("Use 3-20 letters, numbers or _");return;} if(!Pattern.matches("^[^@\\s]+@[^@\\s]+\\.[^@\\s]+$",email)){e.setError("Invalid email");return;} if(!pass.matches("\\d{6}")){p.setError("Exactly 6 digits");return;}if(!pass.equals(c)){cp.setError("Passwords do not match");return;}
            db.collection("users").whereEqualTo("username",user).limit(1).get().addOnSuccessListener(q->{if(!q.isEmpty()){u.setError("Username already exists");return;}auth.createUserWithEmailAndPassword(email,pass).addOnSuccessListener(r->{String uid=r.getUser().getUid();Map<String,Object>d=new HashMap<>();d.put("username",user);d.put("email",email);d.put("wallet",0L);d.put("role","user");d.put("createdAt",FieldValue.serverTimestamp());db.collection("users").document(uid).set(d).addOnSuccessListener(z->{Map<String,Object>idx=new HashMap<>();idx.put("email",email);idx.put("uid",uid);db.collection("usernames").document(user.toLowerCase(Locale.US)).set(idx).addOnSuccessListener(k->{toast("Registration successful");routeAfterLogin();});});}).addOnFailureListener(ex->toast(ex.getMessage()));});
        });back.setOnClickListener(v->showLogin());
    }

    void showHome(){
        base(); box.addView(logo(),new LinearLayout.LayoutParams(-1,170)); TextView h=tv("MATCH FOUND",28);h.setGravity(Gravity.CENTER);box.addView(h); TextView sub=tv("Available Free Fire tournaments",16);sub.setGravity(Gravity.CENTER);box.addView(sub);space(5);
        LinearLayout nav=new LinearLayout(this);nav.setOrientation(LinearLayout.HORIZONTAL); Button my=bt("My Matches"),res=bt("Results"),prof=bt("Profile");nav.addView(my,new LinearLayout.LayoutParams(0,55,1));nav.addView(res,new LinearLayout.LayoutParams(0,55,1));nav.addView(prof,new LinearLayout.LayoutParams(0,55,1));box.addView(nav);space(8);
        LinearLayout list=new LinearLayout(this);list.setOrientation(LinearLayout.VERTICAL);box.addView(list);
        db.collection("matches").orderBy("startAt",Query.Direction.ASCENDING).addSnapshotListener((snap,err)->{list.removeAllViews();if(err!=null){list.addView(tv("Unable to load matches: "+err.getMessage(),16));return;}if(snap==null||snap.isEmpty()){list.addView(tv("No matches found",18));return;}for(DocumentSnapshot d:snap.getDocuments())addMatch(list,d);});
        my.setOnClickListener(v->showMyMatches());res.setOnClickListener(v->showResults());prof.setOnClickListener(v->showProfile());
        Button dep=wide("DEPOSIT MONEY");dep.setOnClickListener(v->showDeposit()); Button out=wide("WITHDRAW MONEY");out.setOnClickListener(v->showWithdraw()); Button refresh=wide("REFRESH MATCHES");refresh.setOnClickListener(v->showHome()); Button logout=wide("LOGOUT");logout.setOnClickListener(v->{auth.signOut();showLogin();});
    }

    void addMatch(LinearLayout list,DocumentSnapshot d){
        String title=safe(d.getString("title"),"Tournament"),mode=safe(d.getString("mode"),"Solo"),map=safe(d.getString("map"),"Bermuda"),start=d.getString("startLabel"),status=safe(d.getString("status"),"open");
        long prize=val(d,"prize",0),kill=val(d,"perKill",0),fee=val(d,"entryFee",0),max=val(d,"maxPlayers",48),joined=val(d,"joined",0);
        LinearLayout card=new LinearLayout(this);card.setOrientation(LinearLayout.VERTICAL);card.setPadding(18,16,18,14);card.setBackground(bg(0xfff7f7f8,24,0));
        TextView titleTv=darkTv("🎮 "+title,22);titleTv.setTypeface(null,1);card.addView(titleTv);card.addView(darkTv(mode+"  •  "+map,15));card.addView(darkTv("WIN PRIZE: "+prize+" TK    PER KILL: "+kill+" TK",15));card.addView(darkTv("ENTRY FEE: "+fee+" TK    PLAYERS: "+joined+"/"+max,15));card.addView(darkTv("SPOTS LEFT: "+Math.max(0,max-joined)+(start==null||start.isEmpty()?"":"    START: "+start),15));TextView st=darkTv("STATUS: "+status.toUpperCase(Locale.US),14);card.addView(st);
        list.addView(card,new LinearLayout.LayoutParams(-1,-2));spaceIn(list,7);
        Button join=bt(joined>=max?"MATCH FULL":"JOIN MATCH  •  "+fee+" TK");join.setEnabled(joined<max&&"open".equalsIgnoreCase(status));list.addView(join,new LinearLayout.LayoutParams(-1,55));join.setOnClickListener(v->joinMatch(d));spaceIn(list,13);
    }
    void spaceIn(LinearLayout p,int h){TextView x=new TextView(this);p.addView(x,new LinearLayout.LayoutParams(1,h));}

    void joinMatch(DocumentSnapshot d){
        String mode=safe(d.getString("mode"),"Solo");int players=teamSize(mode);LinearLayout form=new LinearLayout(this);form.setOrientation(LinearLayout.VERTICAL);form.setPadding(20,5,20,0);TextView s=darkTv(safe(d.getString("title"),"Tournament")+"\n"+mode+" • Entry Fee: "+val(d,"entryFee",0)+" TK",17);form.addView(s);TextView n=darkTv("আপনার Free Fire In-Game Name দিন",16);form.addView(n);ArrayList<EditText> fields=new ArrayList<>();for(int i=1;i<=players;i++){EditText f=ed("Player "+i+" Name",false);f.setTextColor(0xff222222);f.setHintTextColor(0xff777777);form.addView(f,new LinearLayout.LayoutParams(-1,58));fields.add(f);}AlertDialog dialog=new AlertDialog.Builder(this).setTitle("Join Match").setView(form).setNegativeButton("Cancel",null).setPositiveButton("Join Now",null).create();dialog.setOnShowListener(x->{dialog.getButton(-1).setOnClickListener(v->{ArrayList<String>names=new ArrayList<>();for(EditText f:fields){String nm=f.getText().toString().trim();if(nm.isEmpty()){f.setError("Required");return;}names.add(nm);}dialog.dismiss();performJoin(d,names,mode);});});dialog.show();
    }
    int teamSize(String mode){String m=mode.toLowerCase(Locale.US);if(m.contains("squad"))return 4;if(m.contains("duo"))return 2;return 1;}
    void performJoin(DocumentSnapshot d,ArrayList<String>names,String mode){long fee=val(d,"entryFee",0);new AlertDialog.Builder(this).setTitle("Confirm Join").setMessage("Mode: "+mode+"\nPlayers: "+names.size()+"\nEntry Fee: "+fee+" TK").setNegativeButton("Cancel",null).setPositiveButton("Confirm",(x,w)->{String uid=auth.getUid();DocumentReference u=db.collection("users").document(uid),m=db.collection("matches").document(d.getId()),p=m.collection("players").document(uid);db.runTransaction(t->{DocumentSnapshot user=t.get(u),match=t.get(m),player=t.get(p);long wallet=val(user,"wallet",0),joined=val(match,"joined",0),max=val(match,"maxPlayers",48),f=val(match,"entryFee",0);if(player.exists())throw new RuntimeException("You already joined this match");if(!"open".equalsIgnoreCase(safe(match.getString("status"),"open")))throw new RuntimeException("Match closed");if(joined>=max)throw new RuntimeException("Match full");if(wallet<f)throw new RuntimeException("Insufficient wallet balance");t.update(u,"wallet",wallet-f);t.update(m,"joined",joined+1);Map<String,Object>pm=new HashMap<>();pm.put("uid",uid);pm.put("username",user.getString("username"));pm.put("playerNames",names);pm.put("gameName",names.get(0));pm.put("mode",mode);pm.put("joinedAt",FieldValue.serverTimestamp());pm.put("status","joined");t.set(p,pm);return null;}).addOnSuccessListener(z->toast("Match joined successfully")).addOnFailureListener(z->toast(z.getMessage()));}).show();}

    void showProfile(){
        base();TextView h=tv("PROFILE",28);h.setGravity(Gravity.CENTER);box.addView(h);TextView info=tv("Loading profile...",17);box.addView(info);String uid=auth.getUid();db.collection("users").document(uid).get().addOnSuccessListener(d->{long w=val(d,"wallet",0);info.setText("Username: "+safe(d.getString("username"),"-")+"\nEmail: "+safe(d.getString("email"),"-")+"\n\n💰 Wallet Balance: "+w+" TK");});
        Button wallet=wide("WALLET");wallet.setOnClickListener(v->showWallet());Button dep=wide("DEPOSIT");dep.setOnClickListener(v->showDeposit());Button out=wide("WITHDRAW");out.setOnClickListener(v->showWithdraw());Button matches=wide("MY MATCHES");matches.setOnClickListener(v->showMyMatches());Button results=wide("RESULTS / WINNINGS");results.setOnClickListener(v->showResults());Button rules=wide("ALL RULES");rules.setOnClickListener(v->showRules());Button top=wide("TOP PLAYERS");top.setOnClickListener(v->showTopPlayers());Button dev=wide("DEVELOPER PROFILE");dev.setOnClickListener(v->showDeveloper());Button logout=wide("LOGOUT");logout.setOnClickListener(v->{auth.signOut();showLogin();});
    }
    void showWallet(){base();TextView h=tv("WALLET",28);h.setGravity(Gravity.CENTER);box.addView(h);TextView w=tv("Loading...",24);w.setGravity(Gravity.CENTER);box.addView(w);db.collection("users").document(auth.getUid()).addSnapshotListener((d,e)->{if(d!=null&&d.exists())w.setText("💰 "+val(d,"wallet",0)+" TK");});Button d=wide("DEPOSIT");d.setOnClickListener(v->showDeposit());Button o=wide("WITHDRAW");o.setOnClickListener(v->showWithdraw());Button back=wide("BACK");back.setOnClickListener(v->showProfile());}

    void showDeposit(){
        base();TextView h=tv("DEPOSIT",28);h.setGravity(Gravity.CENTER);box.addView(h);box.addView(tv("শুধু bKash ও Nagad গ্রহণ করা হবে",16));
        addPaymentRow("bKash",BKASH);addPaymentRow("Nagad",NAGAD);space(8);
        EditText amount=ed("Deposit amount (TK)",false),trx=ed("Transaction ID",false);box.addView(amount,new LinearLayout.LayoutParams(-1,60));space(7);box.addView(trx,new LinearLayout.LayoutParams(-1,60));
        Spinner method=new Spinner(this);ArrayAdapter<String>a=new ArrayAdapter<>(this,android.R.layout.simple_spinner_dropdown_item,new String[]{"bKash","Nagad"});method.setAdapter(a);box.addView(method,new LinearLayout.LayoutParams(-1,55));
        box.addView(tv("নির্দেশনা: উপরের নম্বরে টাকা Send Money করুন। তারপর সঠিক Amount ও Transaction ID দিয়ে Submit করুন।",15));Button submit=wide("SUBMIT / VERIFY DEPOSIT");submit.setOnClickListener(v->{long x;try{x=Long.parseLong(amount.getText().toString().trim());}catch(Exception ex){amount.setError("Enter amount");return;}String tid=trx.getText().toString().trim();if(x<=0){amount.setError("Invalid amount");return;}if(tid.length()<4){trx.setError("Enter Transaction ID");return;}db.collection("users").document(auth.getUid()).get().addOnSuccessListener(u->{Map<String,Object>m=new HashMap<>();m.put("uid",auth.getUid());m.put("username",u.getString("username"));m.put("method",method.getSelectedItem().toString());m.put("paymentNumber",method.getSelectedItem().toString().equals("bKash")?BKASH:NAGAD);m.put("amount",x);m.put("transactionId",tid);m.put("status","pending");m.put("createdAt",FieldValue.serverTimestamp());db.collection("deposits").add(m).addOnSuccessListener(z->{toast("Deposit request submitted");showDepositHistory();}).addOnFailureListener(z->toast(z.getMessage()));});});
        Button hist=wide("DEPOSIT HISTORY");hist.setOnClickListener(v->showDepositHistory());Button back=wide("BACK");back.setOnClickListener(v->showProfile());
    }
    void addPaymentRow(String name,String number){LinearLayout row=new LinearLayout(this);row.setOrientation(LinearLayout.HORIZONTAL);row.setPadding(14,8,14,8);row.setBackground(bg(0xff151a24,18,1));TextView t=tv(name+"  "+number,17);row.addView(t,new LinearLayout.LayoutParams(0,58,1));Button c=bt("COPY");row.addView(c,new LinearLayout.LayoutParams(90,55));c.setOnClickListener(v->{((android.content.ClipboardManager)getSystemService(CLIPBOARD_SERVICE)).setPrimaryClip(ClipData.newPlainText("Payment number",number));toast(name+" number copied");});box.addView(row);space(6);}
    void showDepositHistory(){base();TextView h=tv("DEPOSIT HISTORY",27);h.setGravity(Gravity.CENTER);box.addView(h);LinearLayout list=new LinearLayout(this);list.setOrientation(LinearLayout.VERTICAL);box.addView(list);db.collection("deposits").whereEqualTo("uid",auth.getUid()).orderBy("createdAt",Query.Direction.DESCENDING).addSnapshotListener((s,e)->{list.removeAllViews();if(e!=null){list.addView(tv(e.getMessage(),15));return;}if(s==null||s.isEmpty()){list.addView(tv("No deposit history",16));return;}for(DocumentSnapshot d:s.getDocuments()){TextView x=tv(safe(d.getString("method"),"-")+" • "+val(d,"amount",0)+" TK\nTXN: "+safe(d.getString("transactionId"),"-")+"\nStatus: "+safe(d.getString("status"),"pending").toUpperCase(Locale.US),16);x.setPadding(15,14,15,14);x.setBackground(bg(CARD,18,1));list.addView(x);spaceIn(list,7);}});Button back=wide("BACK");back.setOnClickListener(v->showDeposit());}

    void showWithdraw(){
        base();TextView h=tv("WITHDRAW",28);h.setGravity(Gravity.CENTER);box.addView(h);box.addView(tv("Minimum withdrawal: ৳30\nOnly bKash and Nagad",16));TextView bal=tv("Loading wallet...",20);box.addView(bal);db.collection("users").document(auth.getUid()).get().addOnSuccessListener(d->bal.setText("Wallet Balance: "+val(d,"wallet",0)+" TK"));
        Spinner method=new Spinner(this);method.setAdapter(new ArrayAdapter<>(this,android.R.layout.simple_spinner_dropdown_item,new String[]{"bKash","Nagad"}));box.addView(method,new LinearLayout.LayoutParams(-1,55));EditText number=ed("Your own bKash/Nagad number",false),amount=ed("Withdrawal amount (minimum 30 TK)",false);box.addView(number,new LinearLayout.LayoutParams(-1,60));space(7);box.addView(amount,new LinearLayout.LayoutParams(-1,60));
        Button req=wide("REQUEST WITHDRAW");req.setOnClickListener(v->{long x;try{x=Long.parseLong(amount.getText().toString().trim());}catch(Exception ex){amount.setError("Enter amount");return;}String n=number.getText().toString().trim();if(x<30){amount.setError("Minimum 30 TK");return;}if(n.length()<8){number.setError("Enter your account number");return;}db.collection("users").document(auth.getUid()).get().addOnSuccessListener(u->{if(val(u,"wallet",0)<x){amount.setError("Insufficient wallet balance");return;}Map<String,Object>m=new HashMap<>();m.put("uid",auth.getUid());m.put("username",u.getString("username"));m.put("method",method.getSelectedItem().toString());m.put("accountNumber",n);m.put("amount",x);m.put("status","pending");m.put("createdAt",FieldValue.serverTimestamp());db.collection("withdrawals").add(m).addOnSuccessListener(z->{toast("Withdrawal request submitted");showWithdrawHistory();});});});Button hist=wide("WITHDRAW HISTORY");hist.setOnClickListener(v->showWithdrawHistory());Button back=wide("BACK");back.setOnClickListener(v->showProfile());
    }
    void showWithdrawHistory(){base();TextView h=tv("WITHDRAW HISTORY",27);h.setGravity(Gravity.CENTER);box.addView(h);LinearLayout list=new LinearLayout(this);list.setOrientation(LinearLayout.VERTICAL);box.addView(list);db.collection("withdrawals").whereEqualTo("uid",auth.getUid()).orderBy("createdAt",Query.Direction.DESCENDING).addSnapshotListener((s,e)->{list.removeAllViews();if(e!=null){list.addView(tv(e.getMessage(),15));return;}if(s==null||s.isEmpty()){list.addView(tv("No withdrawal history",16));return;}for(DocumentSnapshot d:s.getDocuments()){TextView x=tv(safe(d.getString("method"),"-")+" • "+val(d,"amount",0)+" TK\nAccount: "+safe(d.getString("accountNumber"),"-")+"\nStatus: "+safe(d.getString("status"),"pending").toUpperCase(Locale.US),16);x.setPadding(15,14,15,14);x.setBackground(bg(CARD,18,1));list.addView(x);spaceIn(list,7);}});Button back=wide("BACK");back.setOnClickListener(v->showWithdraw());}

    void showMyMatches(){base();TextView h=tv("MY MATCHES",28);h.setGravity(Gravity.CENTER);box.addView(h);LinearLayout list=new LinearLayout(this);list.setOrientation(LinearLayout.VERTICAL);box.addView(list);db.collection("matches").get().addOnSuccessListener(s->{list.removeAllViews();for(DocumentSnapshot m:s.getDocuments()){m.getReference().collection("players").document(auth.getUid()).get().addOnSuccessListener(p->{if(p.exists()){TextView x=tv("🎮 "+safe(m.getString("title"),"Tournament")+"\nMode: "+safe(p.getString("mode"),"-")+"\nGame Name: "+safe(p.getString("gameName"),"-")+"\nStatus: "+safe(p.getString("status"),"joined").toUpperCase(Locale.US),17);x.setPadding(16,14,16,14);x.setBackground(bg(CARD,18,1));list.addView(x);spaceIn(list,7);}});}}).addOnFailureListener(e->list.addView(tv(e.getMessage(),15)));Button back=wide("BACK TO MATCHES");back.setOnClickListener(v->showHome());}

    void showResults(){base();TextView h=tv("RESULTS / WINNINGS",28);h.setGravity(Gravity.CENTER);box.addView(h);LinearLayout list=new LinearLayout(this);list.setOrientation(LinearLayout.VERTICAL);box.addView(list);db.collection("matches").get().addOnSuccessListener(s->{for(DocumentSnapshot m:s.getDocuments()){m.getReference().collection("results").document(auth.getUid()).get().addOnSuccessListener(r->{if(r.exists()){long prize=val(r,"prize",0);TextView x=tv("🏆 "+safe(m.getString("title"),"Tournament")+"\nPosition: "+val(r,"position",0)+"\nPrize / Winnings: "+prize+" TK\n"+safe(r.getString("note"),"Result published"),17);x.setPadding(16,14,16,14);x.setBackground(bg(CARD,18,1));list.addView(x);spaceIn(list,7);}});}});Button back=wide("BACK TO MATCHES");back.setOnClickListener(v->showHome());}

    void showRules(){base();TextView h=tv("ALL RULES",28);h.setGravity(Gravity.CENTER);box.addView(h);box.addView(tv("1. Match join করার আগে wallet balance নিশ্চিত করুন.\n2. Join করার সময় সঠিক Free Fire name দিন.\n3. Entry fee join করার সময় wallet থেকে কাটা হবে.\n4. Deposit শুধু bKash/Nagad-এর মাধ্যমে হবে.\n5. Withdrawal minimum ৳30 এবং নিজের bKash/Nagad নম্বর দিতে হবে.\n6. ভুল Transaction ID বা ভুল payment information দিলে request reject হতে পারে.\n7. Match result admin প্রকাশ করার পর Results-এ দেখা যাবে.\n8. Tournament-এর নির্দিষ্ট নিয়ম admin-এর ঘোষণাই প্রযোজ্য।",16));Button back=wide("BACK");back.setOnClickListener(v->showProfile());}
    void showTopPlayers(){base();TextView h=tv("TOP PLAYERS",28);h.setGravity(Gravity.CENTER);box.addView(h);box.addView(tv("Leaderboard is based on published results.",15));db.collection("users").orderBy("totalPrize",Query.Direction.DESCENDING).limit(20).get().addOnSuccessListener(s->{if(s.isEmpty()){box.addView(tv("No published leaderboard yet.",16));return;}int rank=1;for(DocumentSnapshot d:s.getDocuments()){TextView x=tv("#"+(rank++)+"  👤 "+safe(d.getString("username"),"Player")+"  •  Winnings: "+val(d,"totalPrize",0)+" TK  •  Wins: "+val(d,"wins",0),16);box.addView(x);}}).addOnFailureListener(e->box.addView(tv("Leaderboard not available yet.",16)));Button back=wide("BACK");back.setOnClickListener(v->showProfile());}
    void showDeveloper(){base();TextView h=tv("DEVELOPER PROFILE",28);h.setGravity(Gravity.CENTER);box.addView(h);box.addView(tv("TLB ESPORTS TOUR\nTournament platform developer profile\n\nFor support, contact the app administrator.",17));Button back=wide("BACK");back.setOnClickListener(v->showProfile());}
}
