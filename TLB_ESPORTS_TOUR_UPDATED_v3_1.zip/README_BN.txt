TLB Free Fire Tournament App
============================

নতুন Match Found / Match Listing system যোগ করা হয়েছে।

Match card-এ:
- Match ID (#68849 ইত্যাদি)
- Solo / Duo / Squad
- Mobile
- Regular
- Date & Time
- Win Prize: 800 TK
- Per Kill: 10 TK
- Entry Fee: 20 TK
- Bermuda / Mobile তথ্য
- Spots left + 48-player progress
- Join button
- Room Details button
- Prize Pool button
- Starts-in bar
- একাধিক match card

Join চাপলে confirmation dialog আসে এবং Join confirm করলে spots ১টি কমে/filled count বাড়ে।

Authentication:
- Login: Username + ঠিক ৬ সংখ্যার Password
- Sign Up: Username + Email + ঠিক ৬ সংখ্যার Password + Confirm Password

এটি UI/functional prototype। Production-এ Firebase/backend, secure authentication,
real wallet/payment, admin-created matches, room credentials, result verification,
anti-fraud এবং server-side countdown প্রয়োজন।

APK:
এই পরিবেশে Android SDK/Build Tools/Gradle dependencies না থাকায় installable APK compile করা সম্ভব হয়নি।
Android Studio-তে project খুলে Build > Build APK(s) করলে APK তৈরি হবে।
